'''
PyMOL Demo Plugin

The plugin resembles the old "Rendering Plugin" from Michael Lerner, which
was written with Tkinter instead of PyQt.

(c) Schrodinger, Inc.

License: BSD-2-Clause
'''

from __future__ import absolute_import
from __future__ import print_function

# Avoid importing "expensive" modules here (e.g. scipy), since this code is
# executed on PyMOL's startup. Only import such modules inside functions.

import os


def __init_plugin__(app=None):
    '''
    Add an entry to the PyMOL "Plugin" menu
    '''
    from pymol.plugins import addmenuitemqt
    addmenuitemqt('SibiPlugin', run_plugin_gui)


# global reference to avoid garbage collection of our dialog
dialog = None


def run_plugin_gui():
    '''
    Open our custom dialog
    '''
    global dialog

    if dialog is None:
        dialog = make_dialog()

    dialog.show()


def make_dialog():
    # entry point to PyMOL's API
    from pymol import cmd

    # pymol.Qt provides the PyQt5 interface, but may support PyQt4
    # and/or PySide as well
    from pymol.Qt import QtWidgets
    from pymol.Qt.utils import loadUi

    # create a new Window
    dialog = QtWidgets.QDialog()

    # populate the Window from our *.ui file which was created with the Qt Designer
    uifile = os.path.join(os.path.dirname(__file__), 'demowidget.ui')
    form = loadUi(uifile, dialog)

    def apply_style():
        cmd.bg_color("white")
        cmd.remove("hydro")
        cmd.remove("solvent")
        cmd.set("cartoon_color", "purple")
        cmd.color("atomic", "polymer")
        cmd.set("ray_shadows", 0)
        cmd.set("ray_trace_fog", 0)
        cmd.set("cartoon_side_chain_helper", "on")
        cmd.set("antialias_shader", 2)
        cmd.set("surface_quality", 1)
        cmd.set("line_smooth", 1)
        cmd.set("cartoon_sampling", 19)
        cmd.set("use_shaders", 1)
        cmd.set("cartoon_use_shader", 1)
        cmd.set("cartoon_nucleic_acid_as_cylinders", 1)
        cmd.set("stick_ball", 0)
        cmd.set("sphere_mode", 9)

    # callback for the "Ray Trace" button
    def run():
        if form.SibiStyleSign.isChecked():
            apply_style()
        elif form.BrownStyleSign.isChecked():
            apply_style()
        elif form.OtherButton.isChecked():
            apply_style()

        cmd.ray(quiet=0)

    form.RayTraceSign.clicked.connect(run)

    return dialog
