'''
PyMOL Demo Plugin

The plugin resembles the old "Rendering Plugin" from Michael Lerner, which
was written with Tkinter instead of PyQt.

(c) Schrodinger, Inc.

License: BSD-2-Clause
'''

from __future__ import absolute_import
from __future__ import print_function

# Avoid importing "expensive" modules here (e.g. scipy), since this code is
# executed on PyMOL's startup. Only import such modules inside functions.

import os
import subprocess
import tempfile
import shutil


def __init_plugin__(app=None):
    '''
    Add an entry to the PyMOL "Plugin" menu
    '''
    from pymol.plugins import addmenuitemqt
    addmenuitemqt('SibiPlugin', run_plugin_gui)


# global reference to avoid garbage collection of our dialog
dialog = None


def run_plugin_gui():
    '''
    Open our custom dialog
    '''
    global dialog

    if dialog is None:
        dialog = make_dialog()

    dialog.show()


def make_dialog():
    # entry point to PyMOL's API
    from pymol import cmd

    # pymol.Qt provides the PyQt5 interface, but may support PyQt4
    # and/or PySide as well
    from pymol.Qt import QtWidgets
    from pymol.Qt.utils import loadUi

    # create a new Window
    dialog = QtWidgets.QDialog()

    # populate the Window from our *.ui file which was created with the Qt Designer
    uifile = os.path.join(os.path.dirname(__file__), 'demowidget.ui')
    form = loadUi(uifile, dialog)

    def reset_style_defaults():
        cmd.set("cartoon_fancy_helices", 0)
        cmd.set("cartoon_smooth_loops", 0)
        cmd.set("cartoon_flat_sheets", 1)
        cmd.set("cartoon_loop_radius", 0.2)
        cmd.set("ambient", 0.1)
        cmd.set("direct", 0.45)
        cmd.set("specular", 0.5)
        cmd.set("depth_cue", 1)
        cmd.set("ray_trace_mode", 0)
        cmd.set("ambient_occlusion_mode", 0)
        cmd.set("ambient_occlusion_scale", 25)
        cmd.set("ambient_occlusion_smooth", 9)

    def apply_sibi_style():
        reset_style_defaults()
        cmd.bg_color("white")
        cmd.remove("hydro")
        cmd.remove("solvent")
        cmd.set("ray_shadows", 0)
        cmd.set("ray_trace_fog", 0)
        cmd.set("cartoon_side_chain_helper", "on")
        cmd.set("antialias_shader", 2)
        cmd.set("surface_quality", 1)
        cmd.set("line_smooth", 1)
        cmd.set("cartoon_sampling", 19)
        cmd.set("use_shaders", 1)
        cmd.set("cartoon_use_shader", 1)
        cmd.set("cartoon_nucleic_acid_as_cylinders", 1)
        cmd.set("stick_ball", 0)
        cmd.set("sphere_mode", 9)
        cmd.show("cartoon")
        cmd.hide("lines")

    def apply_brown_style():
        reset_style_defaults()
        cmd.bg_color("white")
        cmd.remove("hydro")
        cmd.remove("solvent")
        cmd.set("ray_shadows", 0)
        cmd.set("ray_trace_fog", 0)
        cmd.set("cartoon_side_chain_helper", "on")
        cmd.set("antialias_shader", 2)
        cmd.set("surface_quality", 1)
        cmd.set("line_smooth", 1)
        cmd.set("cartoon_sampling", 19)
        cmd.set("use_shaders", 1)
        cmd.set("cartoon_use_shader", 1)
        cmd.set("cartoon_nucleic_acid_as_cylinders", 1)
        cmd.set("stick_ball", 0)
        cmd.set("sphere_mode", 9)
        cmd.show("cartoon")
        cmd.hide("lines")
        # cartoon quality
        cmd.set("cartoon_fancy_helices", 1)
        cmd.set("cartoon_smooth_loops", 1)
        cmd.set("cartoon_flat_sheets", 1)
        cmd.set("cartoon_loop_radius", 0.3)
        # lighting
        cmd.set("ambient", 0.4)
        cmd.set("direct", 0.7)
        cmd.set("specular", 0.1)
        cmd.set("depth_cue", 0)
        # ray trace mode with ambient occlusion
        cmd.set("ray_trace_mode", 1)
        cmd.set("ambient_occlusion_mode", 1)
        cmd.set("ambient_occlusion_scale", 25)
        cmd.set("ambient_occlusion_smooth", 9)

    # map UI color names to PyMOL color names
    color_map = {
        "Green": "green", "Greencyan": "greencyan", "Red": "red", "Blue": "blue", "Cyan": "cyan",
        "Firebrick": "firebrick", "Yellow": "yellow", "Marine": "marine", "Wheat": "wheat", "Orange": "orange",
        "Pink": "pink", "Purple": "purple", "White": "white", "Gray": "gray",
        "Light Blue": "lightblue",
    }

    def apply_ligand_color():
        if not form.YesLigandButton.isChecked():
            return
        if "sele" not in cmd.get_names("selections"):
            return
        ligand_color = color_map.get(form.LigandColorDropdown.currentText(), "yellow")
        cmd.color(ligand_color, "sele")
        cmd.color("blue", "sele and elem N")
        cmd.color("red", "sele and elem O")
        cmd.color("yellow", "sele and elem S")

    def on_color_change(color_name):
        pymol_color = color_map.get(color_name, "white")
        cmd.color(pymol_color, "polymer")

    def on_transparency_change(value):
        transparency = value / 99.0
        if form.YesLigandButton.isChecked() and "sele" in cmd.get_names("selections"):
            target = "polymer and not sele"
        else:
            target = "polymer"
        cmd.set("cartoon_transparency", transparency, target)
        cmd.set("surface_transparency", transparency, target)
        cmd.set("stick_transparency", transparency, target)

    # --- Pocket Analysis tab ---

    fpocket_output_dir = [None]  # mutable container to share across closures

    pocket_colors = [
        "tv_red", "tv_orange", "tv_yellow", "tv_green", "tv_blue",
        "violet", "cyan", "salmon", "lime", "pink",
    ]

    def populate_object_dropdown():
        form.fpocketObjectDropdown.clear()
        for obj in cmd.get_object_list():
            form.fpocketObjectDropdown.addItem(obj)

    def run_fpocket():
        obj_name = form.fpocketObjectDropdown.currentText()
        if not obj_name:
            form.fpocketStatusLabel.setText("No object selected.")
            return

        fpocket_bin = shutil.which("fpocket")
        if not fpocket_bin:
            for candidate in [
                "/opt/anaconda3/bin/fpocket",
                "/opt/miniconda3/bin/fpocket",
                "/usr/local/bin/fpocket",
                "/usr/bin/fpocket",
                os.path.expanduser("~/anaconda3/bin/fpocket"),
                os.path.expanduser("~/miniconda3/bin/fpocket"),
            ]:
                if os.path.isfile(candidate):
                    fpocket_bin = candidate
                    break
        if not fpocket_bin:
            form.fpocketStatusLabel.setText("Error: fpocket not found on PATH.")
            return

        form.fpocketStatusLabel.setText("Running fpocket...")
        form.fpocketRunButton.setEnabled(False)
        form.fpocketResultsList.clear()

        tmp_dir = tempfile.mkdtemp()
        tmp_pdb = os.path.join(tmp_dir, obj_name + ".pdb")

        try:
            cmd.save(tmp_pdb, obj_name)
            result = subprocess.run(
                [fpocket_bin, "-f", tmp_pdb],
                capture_output=True, text=True, cwd=tmp_dir
            )
            if result.returncode != 0:
                form.fpocketStatusLabel.setText("fpocket error: " + result.stderr.strip())
                return

            out_dir = os.path.join(tmp_dir, obj_name + "_out")
            fpocket_output_dir[0] = out_dir

            # parse pocket info file for scores
            info_file = os.path.join(out_dir, obj_name + "_info.txt")
            pockets = []
            if os.path.exists(info_file):
                current_pocket = None
                with open(info_file) as f:
                    for line in f:
                        line = line.strip()
                        if line.startswith("Pocket"):
                            current_pocket = line.split()[1].rstrip(":")
                        if "Druggability Score" in line and current_pocket is not None:
                            score = line.split(":")[-1].strip()
                            pockets.append((current_pocket, score))
                            current_pocket = None

            if not pockets:
                form.fpocketStatusLabel.setText("No pockets detected.")
            else:
                form.fpocketStatusLabel.setText(f"Found {len(pockets)} pocket(s).")
                for num, score in pockets:
                    form.fpocketResultsList.addItem(f"Pocket {num}  |  Druggability: {score}")

        except Exception as e:
            form.fpocketStatusLabel.setText("Error: " + str(e))
        finally:
            form.fpocketRunButton.setEnabled(True)

    def load_pocket(pocket_num, color):
        out_dir = fpocket_output_dir[0]
        if not out_dir:
            return
        pocket_pdb = os.path.join(out_dir, "pockets", f"pocket{pocket_num}_atm.pdb")
        if not os.path.exists(pocket_pdb):
            form.fpocketStatusLabel.setText(f"Pocket {pocket_num} file not found.")
            return
        pocket_obj = f"pocket_{pocket_num}"
        cmd.load(pocket_pdb, pocket_obj)
        cmd.show("surface", pocket_obj)
        cmd.color(color, pocket_obj)
        cmd.set("transparency", 0.3, pocket_obj)

    def show_selected_pocket():
        selected = form.fpocketResultsList.currentItem()
        if not selected:
            form.fpocketStatusLabel.setText("No pocket selected in list.")
            return
        pocket_num = selected.text().split()[1]
        idx = form.fpocketResultsList.currentRow()
        color = pocket_colors[idx % len(pocket_colors)]
        load_pocket(pocket_num, color)

    def show_all_pockets():
        if fpocket_output_dir[0] is None:
            form.fpocketStatusLabel.setText("Run fpocket first.")
            return
        for i in range(form.fpocketResultsList.count()):
            pocket_num = form.fpocketResultsList.item(i).text().split()[1]
            color = pocket_colors[i % len(pocket_colors)]
            load_pocket(pocket_num, color)

    def clear_pockets():
        for obj in cmd.get_object_list():
            if obj.startswith("pocket_"):
                cmd.delete(obj)
        form.fpocketStatusLabel.setText("Pockets cleared.")

    populate_object_dropdown()

    form.fpocketRunButton.clicked.connect(run_fpocket)
    form.fpocketShowSelectedButton.clicked.connect(show_selected_pocket)
    form.fpocketShowAllButton.clicked.connect(show_all_pockets)
    form.fpocketClearButton.clicked.connect(clear_pockets)

    form.YesLigandButton.toggled.connect(lambda checked: apply_ligand_color() if checked else None)
    form.YesLigandButton.toggled.connect(lambda _: on_transparency_change(form.TransparencySlider.value()))
    form.NoLigandButton.toggled.connect(lambda _: on_transparency_change(form.TransparencySlider.value()))
    form.LigandColorDropdown.currentTextChanged.connect(lambda _: apply_ligand_color())
    form.SibiStyleSign.toggled.connect(lambda checked: apply_sibi_style() if checked else None)
    form.BrownStyleSign.toggled.connect(lambda checked: apply_brown_style() if checked else None)
    form.OtherButton.toggled.connect(lambda checked: apply_sibi_style() if checked else None)
    form.ProteinColorDropdown.currentTextChanged.connect(on_color_change)
    form.TransparencySlider.valueChanged.connect(on_transparency_change)

    return dialog
