'''
PyMOL Demo Plugin

The plugin resembles the old "Rendering Plugin" from Michael Lerner, which
was written with Tkinter instead of PyQt.

(c) Schrodinger, Inc.

License: BSD-2-Clause
'''

from __future__ import absolute_import
from __future__ import print_function

# Avoid importing "expensive" modules here (e.g. scipy), since this code is
# executed on PyMOL's startup. Only import such modules inside functions.

import os
import threading


def __init_plugin__(app=None):
    '''
    Add an entry to the PyMOL "Plugin" menu
    '''
    from pymol.plugins import addmenuitemqt
    addmenuitemqt('SibiPlugin', run_plugin_gui)


# global reference to avoid garbage collection of our dialog
dialog = None


def run_plugin_gui():
    '''
    Open our custom dialog
    '''
    global dialog

    if dialog is None:
        dialog = make_dialog()

    dialog.show()


def make_dialog():
    # entry point to PyMOL's API
    from pymol import cmd

    # pymol.Qt provides the PyQt5 interface, but may support PyQt4
    # and/or PySide as well
    from pymol.Qt import QtWidgets, QtCore
    from pymol.Qt.utils import loadUi, getSaveFileNameWithExt

    # create a new Window
    dialog = QtWidgets.QDialog()

    # populate the Window from our *.ui file which was created with the Qt Designer
    uifile = os.path.join(os.path.dirname(__file__), 'demowidget.ui')
    form = loadUi(uifile, dialog)

    def reset_style_defaults():
        cmd.set("cartoon_fancy_helices", 0)
        cmd.set("cartoon_smooth_loops", 0)
        cmd.set("cartoon_flat_sheets", 1)
        cmd.set("cartoon_loop_radius", 0.2)
        cmd.set("ambient", 0.1)
        cmd.set("direct", 0.45)
        cmd.set("specular", 0.5)
        cmd.set("depth_cue", 1)
        cmd.set("ray_trace_mode", 0)
        cmd.set("ambient_occlusion_mode", 0)
        cmd.set("ambient_occlusion_scale", 25)
        cmd.set("ambient_occlusion_smooth", 9)

    def apply_sibi_style():
        reset_style_defaults()
        cmd.bg_color("white")
        cmd.remove("hydro")
        cmd.remove("solvent")
        cmd.set("ray_shadows", 0)
        cmd.set("ray_trace_fog", 0)
        cmd.set("cartoon_side_chain_helper", "on")
        cmd.set("antialias_shader", 2)
        cmd.set("surface_quality", 1)
        cmd.set("line_smooth", 1)
        cmd.set("cartoon_sampling", 19)
        cmd.set("use_shaders", 1)
        cmd.set("cartoon_use_shader", 1)
        cmd.set("cartoon_nucleic_acid_as_cylinders", 1)
        cmd.set("stick_ball", 0)
        cmd.set("sphere_mode", 9)
        cmd.show("cartoon")
        cmd.hide("lines")

    def apply_brown_style():
        reset_style_defaults()
        cmd.bg_color("white")
        cmd.remove("hydro")
        cmd.remove("solvent")
        cmd.set("ray_shadows", 0)
        cmd.set("ray_trace_fog", 0)
        cmd.set("cartoon_side_chain_helper", "on")
        cmd.set("antialias_shader", 2)
        cmd.set("surface_quality", 1)
        cmd.set("line_smooth", 1)
        cmd.set("cartoon_sampling", 19)
        cmd.set("use_shaders", 1)
        cmd.set("cartoon_use_shader", 1)
        cmd.set("cartoon_nucleic_acid_as_cylinders", 1)
        cmd.set("stick_ball", 0)
        cmd.set("sphere_mode", 9)
        cmd.show("cartoon")
        cmd.hide("lines")
        # cartoon quality
        cmd.set("cartoon_fancy_helices", 1)
        cmd.set("cartoon_smooth_loops", 1)
        cmd.set("cartoon_flat_sheets", 1)
        cmd.set("cartoon_loop_radius", 0.3)
        # lighting
        cmd.set("ambient", 0.4)
        cmd.set("direct", 0.7)
        cmd.set("specular", 0.1)
        cmd.set("depth_cue", 0)
        # ray trace mode with ambient occlusion
        cmd.set("ray_trace_mode", 1)
        cmd.set("ambient_occlusion_mode", 1)
        cmd.set("ambient_occlusion_scale", 25)
        cmd.set("ambient_occlusion_smooth", 9)

    # map UI color names to PyMOL color names
    color_map = {
        "Green": "green","Red": "red", "Blue": "blue", "Cyan": "cyan",
        "Firebrick": "firebrick", "Yellow": "yellow", "Orange": "orange",
        "Pink": "pink", "Purple": "purple", "White": "white", "Gray": "gray",
        "Light Blue": "lightblue",
    }

    def apply_ligand_color():
        if not form.YesLigandButton.isChecked():
            return
        if "sele" not in cmd.get_names("selections"):
            return
        ligand_color = color_map.get(form.LigandColorDropdown.currentText(), "yellow")
        cmd.color(ligand_color, "sele")
        cmd.color("blue", "sele and elem N")
        cmd.color("red", "sele and elem O")
        cmd.color("yellow", "sele and elem S")

    def on_color_change(color_name):
        pymol_color = color_map.get(color_name, "white")
        cmd.color(pymol_color, "polymer")

    def on_transparency_change(value):
        transparency = value / 99.0
        if form.YesLigandButton.isChecked() and "sele" in cmd.get_names("selections"):
            target = "polymer and not sele"
        else:
            target = "polymer"
        cmd.set("cartoon_transparency", transparency, target)
        cmd.set("surface_transparency", transparency, target)
        cmd.set("stick_transparency", transparency, target)

    # callback for the "Ray Trace" button
    def run():
        filename = getSaveFileNameWithExt(dialog, 'Save As...', filter='PNG File (*.png)')
        if not filename:
            return

        width, ok = QtWidgets.QInputDialog.getInt(dialog, 'Width', 'Image width (pixels):', 1200, 100, 10000)
        if not ok:
            return
        height, ok = QtWidgets.QInputDialog.getInt(dialog, 'Height', 'Image height (pixels):', 1200, 100, 10000)
        if not ok:
            return
        dpi, ok = QtWidgets.QInputDialog.getInt(dialog, 'DPI', 'DPI:', 300, 72, 1200)
        if not ok:
            return

        color_name = form.ProteinColorDropdown.currentText()
        pymol_color = color_map.get(color_name, "white")

        if form.SibiStyleSign.isChecked():
            apply_sibi_style()
        elif form.BrownStyleSign.isChecked():
            apply_brown_style()
        elif form.OtherButton.isChecked():
            apply_sibi_style()

        cmd.color(pymol_color, "polymer")
        on_transparency_change(form.TransparencySlider.value())
        apply_ligand_color()

        form.RayTraceProgress.setRange(0, 100)
        form.RayTraceProgress.setValue(0)
        form.RayTraceSign.setEnabled(False)

        thread = threading.Thread(
            target=lambda: cmd.png(filename, width, height, dpi=dpi, ray=1, quiet=0)
        )
        thread.start()

        timer = QtCore.QTimer()
        def update_progress():
            progress = cmd.get_progress()
            if progress >= 0:
                form.RayTraceProgress.setValue(int(progress * 100))
            if not thread.is_alive():
                timer.stop()
                form.RayTraceProgress.setValue(100)
                form.RayTraceSign.setEnabled(True)
        timer.timeout.connect(update_progress)
        timer.start(100)

    form.YesLigandButton.toggled.connect(lambda checked: apply_ligand_color() if checked else None)
    form.YesLigandButton.toggled.connect(lambda _: on_transparency_change(form.TransparencySlider.value()))
    form.NoLigandButton.toggled.connect(lambda _: on_transparency_change(form.TransparencySlider.value()))
    form.LigandColorDropdown.currentTextChanged.connect(lambda _: apply_ligand_color())
    form.SibiStyleSign.toggled.connect(lambda checked: apply_sibi_style() if checked else None)
    form.BrownStyleSign.toggled.connect(lambda checked: apply_brown_style() if checked else None)
    form.OtherButton.toggled.connect(lambda checked: apply_sibi_style() if checked else None)
    form.ProteinColorDropdown.currentTextChanged.connect(on_color_change)
    form.TransparencySlider.valueChanged.connect(on_transparency_change)
    form.RayTraceSign.clicked.connect(run)

    return dialog
